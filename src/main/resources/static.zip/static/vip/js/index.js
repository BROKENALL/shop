$(function (){
    $("#shopcart").click(function () {
        $(location).attr('href','http://localhost:8080/vip/shopcart');
    });

    $("#shopCartNo").click(function (){
        $(location).attr('href','http://localhost:8080/vip/shopcart');
    });

    if(vipName){
        console.log("可以");
       $("#please1").hide();
        $("#please2").hide();
        console.log("123")
    }else {
        console.log("不可以");
        $("#please").hide();
    }


    $("#ai-topsearch").click(function (){
        console.log("wdwdwd");
        $("#searchInput").submit();
    })




    }


);