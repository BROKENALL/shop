$(function () {
    if (error) {
        layer.alert(error);
    }
    if (success) {
        layer.msg(success);
        setTimeout("","500");
    }
    $("#login-btn").click(function () {
        let email=$("#email").val();
        let password=$("#password").val();
        let passwordRepeat=$("#passwordRepeat").val();
        if (email.trim() === "") {
            layer.alert("账号不可为空");
            return;
        }else if (password.trim() === "") {
            layer.alert("密码不能为空");
            return;
        } else if (email.trim().length < 3) {
            layer.alert("账号不能少于5位");
            return;
        } else if (password.trim().length < 6) {
            layer.alert("密码不能少于6位");
            return;
        } else if (password != passwordRepeat) {
            layer.alert("输入两次密码不一致，请重新输入");
        } else {
            $("#logining").submit();
        }
    });

    $("#loginback-btn").click(function () {
        $(location).attr('href', 'http://localhost:8080/vipLogin');
    });


});
