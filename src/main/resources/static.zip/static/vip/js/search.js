$(function () {

    if (commodityNULL) {
        layer.alert(commodityNULL);
    }


    //控制首页和尾页不能向前或向后翻页
    $(function () {
        if (pageNum == 1) {
            $("#am-first").css("color", "red");
        }
        ;
        if (pageNum == pages) {
            $("#am-last").css("color", "red");
        }
        ;

    });

    //向上页
    $("#am-first").click(function () {
        if (pageNum == 1) {
            $(location).attr('href', 'http://localhost:8080/vip/search?pageNo=1');
        } else {
            $(location).attr('href', 'http://localhost:8080/vip/search?pageNo=' + (pageNum - 1));
        }

    });
//下一页
    $("#am-last").click(function () {
        console.log("ches")
        if (pageNum == pages) {
            return;
        } else {
            $(location).attr('href', 'http://localhost:8080/vip/search?pageNo=' + (pageNum + 1));
        }
    });


    //跳转
    $("#sizeController .p").click(function () {
        console.log("dfsf")
        let num = parseInt($(this).text());
        $(location).attr('href', 'http://localhost:8080/vip/search?pageNo=' + num);
    });

    if (kind) {
        if($("#kind a").text() != kind){
            console.log(this.text)
        }



/*        {
            $(this).addClass("selected").siblings().removeClass("selected");
            if ($(this).hasClass("select-all")) {
                $("#selectA").remove();
            } else {
                var copyThisA = $(this).clone();
                if ($("#selectA").length > 0) {
                    $("#selectA a").html($(this).text());
                } else {
                    $(".select-result dl").append(copyThisA.attr("id", "selectA"));

                }
            }
        }*/


    }

   if(price){
       console.log(0);
        $("#price0").removeAttr("class");
        if(price==1){
            console.log(1);
            $("#price1").parent().addClass("select-all selected");
            $("#priceinput").val(1);
        }
       if(price==2){
           console.log(2);
           $("#price2").parent().addClass("select-all selected");
           $("#priceinput").val(2);
       }
       if(price==3){
           console.log(3);
           $("#price3").parent().addClass("select-all selected");
           $("#priceinput").val(3);
       }
       if(price==4){
           console.log(4);
           $("#price4").parent().addClass("select-all selected");
           $("#priceinput").val(4);
       }
    }

    $("#price0").click(function () {
        $("#clearinput").val("3");
        $("#search-input").submit();
    });
    $("#price1").click(function () {
        $("#priceinput").val("1");
        $("#search-input").submit();
    });
    $("#price2").click(function () {
        $("#priceinput").val("2");
        $("#search-input").submit();
    });
    $("#price3").click(function () {
        $("#priceinput").val("3");
        $("#search-input").submit();
    });
    $("#price4").click(function () {
        $("#priceinput").val("4");
        $("#search-input").submit();
    });

    $("#kind a").click(function () {
        let kindId = (this.text);
        $("#kindinput").val(kindId);
        $("#search-input").submit();
    });

    $("#category a").click(function () {
        let ddd = $($(this).parent()).children(":nth-child(2)").val();
        $("#categoryinput").val(ddd);
        console.log(ddd)
        $("#search-input").submit();

    });



});