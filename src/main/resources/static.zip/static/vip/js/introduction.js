$(function (){


    if(success){
        layer.alert(success);
        success=null;
    }
    if(error){
        layer.alert(error);
        error=null;
    }

    $("#LikBasket").click(function (){
        let num=$("#text_box").val();
        $(location).attr('href','shopcart?commodityId='+commodityId+'&root=introduction&number='+num);

    })

})