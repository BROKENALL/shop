$(function() {
	if(error){
		layer.alert(error);
	}


	$("#login-btn").click(function() {
		let username = $("#username").val();
		let password = $("#password").val();
		if (username.trim() === "") {
			layer.alert("账号不可为空");
			return;
		} else if (password.trim() === "") {
			layer.alert("密码不能为空");
			return;
		} else if (username.trim().length < 3) {
			layer.alert("账号不能少于5位");
			return;
		} else if (password.trim().length < 6) {
			layer.alert("密码不能少于6位");
			return;
		} else {
			$("#logining").submit();

		}
	});

	$("#logput-btn").click(function (){

			$(location).attr('href','http://localhost:8080/vip/register');
	});

});
