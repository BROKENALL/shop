$(function () {
        $("#index").click(function () {
            $(location).attr('href', 'http://localhost:8080/vip/index');
        });
        $("#shopcart").click(function () {
            $(location).attr('href', 'http://localhost:8080/vip/showcart');
        });
        $("#frame").click(function () {
            $(location).attr('href', 'http://localhost:8080/vip/frame');
        });
        $("#collection").click(function () {
            $(location).attr('href', 'http://localhost:8080/vip/collection');
        });
    }
);