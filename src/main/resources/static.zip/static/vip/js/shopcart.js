$(function () {
    layer.msg('asdasd');

    computeTempTotal();
    $("#index").click(function () {
        $(location).attr('href', 'http://localhost:8080/vip/index');
    });

    Math.formatFloat = function (f, digit) {
        var m = Math.pow(10, digit);
        return Math.round(f * m, 10) / m;
    }
    $("#cartItem>ul>li>div>input[type=checkbox]").click(function () {
        computeTempTotal();
    });

//选中删除
    $(".deleteAll").click(function () {
        $("#cartItem>ul>li>div").find(":checked").each(function () {
            let $ul = $(this).closest("ul");
            let id = $(this).next().next().next().val();
            let url = "shopcart/deleteItem";
            $.post(url, {
                id: id
            }, function (resp) {
                if (resp.success) {
                    $ul.remove();
                    computeTempTotal();
                } else {
                    console.log("删除失败！");
                }
            }, "json");
        });
    });

    //删除
    $(".allDelete").click(function () {
        let $ul = $(this).closest("ul");
        let id = $(this).next().val();
        let url = "shopcart/deleteItem";
        $.post(url, {
            id: id
        }, function (resp) {
            if (resp.success) {
                $ul.remove();
                computeTempTotal();
            } else {
                console.log("删除失败！");
            }
        }, "json");

    });


    $("#cartItem>ul>li>div>input[type=checkbox]").click(function () {
        var boxs = [];
        $("#cartItem>ul>li>div>input[type=checkbox]").each(function () {
            boxs.push($(this));
        });
        for (var i = 0; i < boxs.length; i++) {
            if (boxs[i].is(":checked")) {
            } else {
                $("#J_SelectAllCbx2").prop("checked", false);
                return;
            }
            $("#J_SelectAllCbx2").prop("checked", true);
        }
        computeTempTotal();
    });

    $("#J_SelectAllCbx2").click(function () {
        console.log("dasdasd");
        var boxs = [];
        let $lu = $("#cartItem>ul>li>div>input[type=checkbox]").each(function () {
            boxs.push($(this));
        });
        if ($("#J_SelectAllCbx2").is(":checked")) {
            for (var i = 0; i < boxs.length; i++) {
                boxs[i].attr('checked', 'checked');
            }

        } else {
            for (var i = 0; i < boxs.length; i++) {
                boxs[i].prop("checked", false);
            }
        }
        computeTempTotal();
    });

    //结算
    $(".btn-area").click(function () {
        let orderItems = [];
        let ids = [];
        let $lu = $("#cartItem>ul>li>div>input:checked");
        $lu.each(function () {
            let commodityId = parseInt($(this).next().next().next().next().val());
            let id = parseInt($(this).next().next().next().val());
            let number = parseInt($(this).next().next().val());
            let price = parseFloat($(this).next().val());
            orderItems.push({
                commodityId: commodityId,
                number: number,
                price: price
            });
            ids.push({
                id: id
            });
        });
        let url = "pay/add";
        $.ajax({
            url: url,
            data: JSON.stringify(orderItems),
            type: 'post',
            dataType: "json",
            contentType: "application/json",
            success: function (resp) {
                if (resp.success) {
                    for (var i = 0; i < ids.length; i++) {
                        var id = ids[i].id;
                        let url = "shopcart/deleteItem";
                        $.post(url, {
                            id: id
                        }, function (resp) {
                            if (resp.success) {
                            } else {
                                console.log("删除失败！");
                            }
                        }, "json");
                    }
                      location.href = "pay?orderId=" + resp.orderId;
                }
            }
        });

    });

    $("#cartItem>ul>li>div>div>div>input[type=button]").click(function () {
        let num;
        let id;
        if ($(this).val() == "-") {
            num = parseInt($(this).next().val());
            id = $(this).parent().children(":first-child").val();
            if (num == 0) {
                return;
            }
            num--;
        } else if ($(this).val() == "+") {
            num = parseInt($(this).prev().val()) + 1;
            id = $(this).parent().children(":first-child").val();

        }
        computeTempTotal();
        let url = "shopcart/update"
        $.post(url, {
                number: num,
                id: id
            }, function (resp) {
                if (resp.success) {
                    console.log("成功");
                } else {
                    console.log("失败");
                }
            }, "json"
        )

    });

})
;

function computeTempTotal() {
    let atotle = 0;
    let price = 0;
    let allnumber = 0;
    let number = 0;
    let totle = 0;
    $("#cartItem>ul>li>div").find(":checked").each(function () {
        let $tds = $(this).next();
        number = parseInt($tds.next().val());
        allnumber = allnumber + number;
        totle = Math.formatFloat(totle + parseFloat($tds.val() * number), 2);
        atotle = parseFloat($tds.val() * number);
        $(this).parents("li").next().next().next().next().next().children().children().text(atotle);
    });
    $("#J_Total").text(totle);
    $("#J_SelectedItemsCount").text(allnumber);


}